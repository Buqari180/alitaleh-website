// Profile page functionality
const AUTH_STORAGE_KEY = 'alitaleh_user';
const USERS_STORAGE_KEY = 'alitaleh_users';

// Initialize real-time order tracking
let realtimeTrackingInterval;

function startRealtimeOrderTracking() {
    // Clear any existing interval
    if (realtimeTrackingInterval) {
        clearInterval(realtimeTrackingInterval);
    }
    
    // Set up periodic order status checks
    realtimeTrackingInterval = setInterval(() => {
        checkForOrderUpdates();
    }, 30000); // Check every 30 seconds
}

function checkForOrderUpdates() {
    // Get current user
    const user = getCurrentUser();
    if (!user) return;
    
    // Get user data
    const userData = getUserData(user.email);
    if (!userData || !userData.orders || userData.orders.length === 0) return;
    
    // Check for order updates (simulated)
    const orders = userData.orders;
    let hasUpdates = false;
    
    // Randomly update one order for demonstration
    if (Math.random() > 0.7) {
        const randomOrderIndex = Math.floor(Math.random() * orders.length);
        const order = orders[randomOrderIndex];
        
        // Only update if order is not already delivered
        if (order.status !== 'Delivered' && order.status !== 'Cancelled') {
            const statuses = ['Processing', 'In Transit', 'Out for Delivery', 'Delivered'];
            const currentIndex = statuses.indexOf(order.status);
            
            if (currentIndex < statuses.length - 1) {
                const newStatus = statuses[currentIndex + 1];
                order.status = newStatus;
                order.updatedAt = new Date().toISOString();
                hasUpdates = true;
                
                // Show notification
                if (typeof alitalehRT !== 'undefined') {
                    alitalehRT.showNotification(`Order #${order.orderId} status updated to: ${newStatus}`, 'info');
                }
            }
        }
    }
    
    // Update user data if there were changes
    if (hasUpdates) {
        updateUserData(user.email, { orders: orders });
        
        // Reload profile to show updates
        loadProfile();
    }
}

// Get current user
function getCurrentUser() {
    let user = localStorage.getItem(AUTH_STORAGE_KEY);
    if (!user) {
        user = sessionStorage.getItem(AUTH_STORAGE_KEY);
    }
    return user ? JSON.parse(user) : null;
}

// Get user data from users storage
function getUserData(email) {
    const users = JSON.parse(localStorage.getItem(USERS_STORAGE_KEY) || '{}');
    return users[email] || null;
}

// Update user data
function updateUserData(email, data) {
    const users = JSON.parse(localStorage.getItem(USERS_STORAGE_KEY) || '{}');
    if (users[email]) {
        users[email] = { ...users[email], ...data };
        localStorage.setItem(USERS_STORAGE_KEY, JSON.stringify(users));
        
        // Update current session
        const currentUser = getCurrentUser();
        if (currentUser && currentUser.email === email) {
            const updatedSession = { ...currentUser, ...data };
            if (localStorage.getItem(AUTH_STORAGE_KEY)) {
                localStorage.setItem(AUTH_STORAGE_KEY, JSON.stringify(updatedSession));
            } else {
                sessionStorage.setItem(AUTH_STORAGE_KEY, JSON.stringify(updatedSession));
            }
        }
        return true;
    }
    return false;
}

// Load user profile
function loadProfile() {
    const user = getCurrentUser();
    if (!user) {
        window.location.href = 'login.html';
        return;
    }
    
    // Start real-time order tracking
    startRealtimeOrderTracking();
    
    // Update header
    document.getElementById('userNameDisplay').textContent = user.name.split(' ')[0];
    document.getElementById('profileName').textContent = user.name;
    document.getElementById('profileEmail').textContent = user.email;
    
    // Set initials
    const nameParts = user.name.split(' ');
    const initials = nameParts.map(n => n[0]).join('').toUpperCase().substring(0, 2);
    document.getElementById('avatarInitials').textContent = initials;
    
    // Load full user data
    const fullUserData = getUserData(user.email);
    
    // Load stats
    loadStats(fullUserData);
    
    // Load orders
    loadOrders(fullUserData);
    
    // Load personal info
    loadPersonalInfo(user);
    
    // Load addresses
    loadAddresses(fullUserData);
    
    // Load payment methods
    loadPaymentMethods(fullUserData);
    
    // Load preferences
    loadPreferences(fullUserData);
}

// Load statistics
function loadStats(userData) {
    const orders = userData.orders || [];
    const totalOrders = orders.length;
    const activeOrders = orders.filter(o => o.status !== 'Delivered' && o.status !== 'Cancelled').length;
    const completedOrders = orders.filter(o => o.status === 'Delivered').length;
    const itemsPressed = orders.reduce((sum, order) => sum + (order.items || 0), 0);
    
    document.getElementById('totalOrders').textContent = totalOrders;
    document.getElementById('activeOrders').textContent = activeOrders;
    document.getElementById('completedOrders').textContent = completedOrders;
    document.getElementById('itemsPressed').textContent = itemsPressed;
}

// Load orders
function loadOrders(userData) {
    const orders = userData.orders || [];
    const ordersList = document.getElementById('ordersList');
    
    if (orders.length === 0) {
        ordersList.innerHTML = '<p style="color: var(--text-light); text-align: center; padding: 2rem;">No orders yet. <a href="booking.html" style="color: var(--primary-color);">Book your first service!</a></p>';
        return;
    }
    
    ordersList.innerHTML = orders.map(order => `
        <div class="order-card" data-status="${order.status.toLowerCase()}">
            <div class="order-header">
                <div>
                    <h3>Order #${order.orderId}</h3>
                    <p>${new Date(order.date).toLocaleDateString()}</p>
                </div>
                <span class="order-status status-${order.status.toLowerCase().replace(' ', '-')}">${order.status}</span>
            </div>
            <div class="order-body">
                <p><strong>Service:</strong> ${order.service}</p>
                <p><strong>Items:</strong> ${order.items} items</p>
                <p><strong>Total:</strong> $${order.total.toFixed(2)}</p>
            </div>
            <div class="order-footer">
                <a href="track-order.html?id=${order.orderId}" class="btn secondary">Track Order</a>
                ${order.status === 'Delivered' ? '<button class="btn primary">Reorder</button>' : ''}
            </div>
        </div>
    `).join('');
}

// Load personal info
function loadPersonalInfo(user) {
    const nameParts = user.name.split(' ');
    document.getElementById('firstName').value = nameParts[0] || '';
    document.getElementById('lastName').value = nameParts.slice(1).join(' ') || '';
    document.getElementById('email').value = user.email;
    document.getElementById('phone').value = user.phone || '';
}

// Load addresses
function loadAddresses(userData) {
    const addresses = userData.addresses || [];
    const addressesList = document.getElementById('addressesList');
    
    if (addresses.length === 0) {
        addressesList.innerHTML = '<p style="color: var(--text-light); text-align: center; padding: 2rem; grid-column: 1/-1;">No saved addresses</p>';
        return;
    }
    
    addressesList.innerHTML = addresses.map(addr => `
        <div class="address-card">
            <div class="address-header">
                <h3>${addr.type}</h3>
                ${addr.isDefault ? '<span class="default-badge">Default</span>' : ''}
            </div>
            <p>${addr.address}</p>
            <div class="address-actions">
                <button class="btn-link">Edit</button>
                <button class="btn-link" style="color: #ef4444;">Delete</button>
            </div>
        </div>
    `).join('');
}

// Load payment methods
function loadPaymentMethods(userData) {
    const paymentMethods = userData.paymentMethods || [];
    const paymentsList = document.getElementById('paymentsList');
    
    if (paymentMethods.length === 0) {
        paymentsList.innerHTML = '<p style="color: var(--text-light); text-align: center; padding: 2rem; grid-column: 1/-1;">No saved payment methods</p>';
        return;
    }
    
    paymentsList.innerHTML = paymentMethods.map(pm => `
        <div class="payment-card">
            <div class="card-icon">💳</div>
            <div class="card-info">
                <h3>${pm.type}</h3>
                <p>•••• •••• •••• ${pm.last4}</p>
                <p>Expires ${pm.expiry}</p>
            </div>
            ${pm.isDefault ? '<span class="default-badge">Default</span>' : ''}
            <button class="btn-link" style="color: #ef4444;">Remove</button>
        </div>
    `).join('');
}

// Load preferences
function loadPreferences(userData) {
    const prefs = userData.preferences || {};
    
    document.getElementById('emailNotif').checked = prefs.emailNotifications !== false;
    document.getElementById('smsNotif').checked = prefs.smsNotifications !== false;
    document.getElementById('marketingNotif').checked = prefs.marketingCommunications === true;
    document.getElementById('defaultStarch').value = prefs.defaultStarch || 'medium';
}

// Profile navigation
document.querySelectorAll('.profile-nav-item').forEach(item => {
    item.addEventListener('click', () => {
        // Update active nav
        document.querySelectorAll('.profile-nav-item').forEach(i => i.classList.remove('active'));
        item.classList.add('active');
        
        // Show section
        const section = item.dataset.section;
        document.querySelectorAll('.profile-section').forEach(s => s.classList.remove('active'));
        document.getElementById(section).classList.add('active');
    });
});

// Personal info form
const personalInfoForm = document.getElementById('personalInfoForm');
if (personalInfoForm) {
    personalInfoForm.addEventListener('submit', (e) => {
        e.preventDefault();
        
        const user = getCurrentUser();
        const firstName = document.getElementById('firstName').value.trim();
        const lastName = document.getElementById('lastName').value.trim();
        const phone = document.getElementById('phone').value.trim();
        
        const updatedData = {
            name: `${firstName} ${lastName}`,
            phone: phone
        };
        
        if (updateUserData(user.email, updatedData)) {
            alert('Personal information updated successfully! ✅');
            loadProfile();
        }
    });
}

// Change password form
const changePasswordForm = document.getElementById('changePasswordForm');
if (changePasswordForm) {
    changePasswordForm.addEventListener('submit', (e) => {
        e.preventDefault();
        
        const user = getCurrentUser();
        const currentPassword = document.getElementById('currentPassword').value;
        const newPassword = document.getElementById('newPassword').value;
        const confirmNewPassword = document.getElementById('confirmNewPassword').value;
        
        // Get full user data
        const users = JSON.parse(localStorage.getItem(USERS_STORAGE_KEY) || '{}');
        const userData = users[user.email];
        
        if (!userData || userData.password !== currentPassword) {
            alert('Current password is incorrect');
            return;
        }
        
        if (newPassword.length < 8) {
            alert('New password must be at least 8 characters long');
            return;
        }
        
        if (newPassword !== confirmNewPassword) {
            alert('New passwords do not match');
            return;
        }
        
        userData.password = newPassword;
        users[user.email] = userData;
        localStorage.setItem(USERS_STORAGE_KEY, JSON.stringify(users));
        
        alert('Password updated successfully! ✅');
        changePasswordForm.reset();
    });
}

// Order filters
document.querySelectorAll('.order-filters .filter-btn').forEach(btn => {
    btn.addEventListener('click', () => {
        document.querySelectorAll('.order-filters .filter-btn').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        
        const filter = btn.dataset.filter;
        const orders = document.querySelectorAll('.order-card');
        
        orders.forEach(order => {
            if (filter === 'all') {
                order.style.display = 'block';
            } else {
                const status = order.dataset.status;
                if ((filter === 'active' && status !== 'delivered' && status !== 'cancelled') ||
                    (filter === 'completed' && status === 'delivered') ||
                    (filter === 'cancelled' && status === 'cancelled')) {
                    order.style.display = 'block';
                } else {
                    order.style.display = 'none';
                }
            }
        });
    });
});

// Initialize profile on page load
document.addEventListener('DOMContentLoaded', () => {
    if (window.location.pathname.includes('profile.html')) {
        loadProfile();
    }
});
