// Mobile Navigation Toggle
const hamburger = document.querySelector('.hamburger');
const navLinks = document.querySelector('.nav-links');

// Initialize real-time functionality
if (typeof AlitalehRealtime !== 'undefined') {
    window.alitalehRT = new AlitalehRealtime();
}

if (hamburger) {
    hamburger.addEventListener('click', () => {
        navLinks.classList.toggle('active');
        hamburger.classList.toggle('active');
    });
}

// Close mobile menu when clicking on a link
document.querySelectorAll('.nav-links a').forEach(link => {
    link.addEventListener('click', () => {
        navLinks.classList.remove('active');
        hamburger.classList.remove('active');
    });
});

// Mobile dropdown toggle
const dropdownParents = document.querySelectorAll('.has-dropdown > a');
dropdownParents.forEach(link => {
    link.addEventListener('click', (e) => {
        if (window.innerWidth <= 768) {
            e.preventDefault();
            const parent = link.parentElement;
            parent.classList.toggle('active');
        }
    });
});

// Promo Banner Close
const promoBanner = document.getElementById('promoBanner');
const closePromo = document.getElementById('closePromo');

if (closePromo && promoBanner) {
    // Check if banner was previously closed
    const bannerClosed = localStorage.getItem('alitaleh_promo_closed');
    if (bannerClosed) {
        promoBanner.style.display = 'none';
    }

    closePromo.addEventListener('click', () => {
        promoBanner.style.display = 'none';
        localStorage.setItem('alitaleh_promo_closed', 'true');
    });
}

// FAQ Accordion
const faqItems = document.querySelectorAll('.faq-item');

faqItems.forEach(item => {
    const question = item.querySelector('.faq-question');
    
    question.addEventListener('click', () => {
        const isActive = item.classList.contains('active');
        
        // Close all FAQ items
        faqItems.forEach(faq => faq.classList.remove('active'));
        
        // Open clicked item if it wasn't active
        if (!isActive) {
            item.classList.add('active');
        }
    });
});

// Form Validation and Submission
const bookingForm = document.getElementById('bookingForm');

// Calculate order total based on service and items
function calculateOrderTotal(service, items) {
    const servicePrices = {
        basic: 25,
        popular: 45,
        premium: 75,
        individual: 3, // per item
        express: 15, // additional fee
        corporate: 0 // custom pricing
    };
    
    let total = 0;
    
    if (service === 'individual' && items) {
        total = servicePrices.individual * parseInt(items);
    } else if (servicePrices[service]) {
        total = servicePrices[service];
    }
    
    // Add express fee if selected
    if (service === 'express') {
        total += servicePrices.express;
    }
    
    return total;
}

// Save order to localStorage
function saveOrderToLocalStorage(orderId, order) {
    const orders = JSON.parse(localStorage.getItem('alitaleh_orders') || '{}');
    orders[orderId] = order;
    localStorage.setItem('alitaleh_orders', JSON.stringify(orders));
}

// Add order to user's order history
function addOrderToUserHistory(order) {
    // Get current user
    let user = localStorage.getItem('alitaleh_user');
    if (!user) {
        user = sessionStorage.getItem('alitaleh_user');
    }
    
    if (user) {
        user = JSON.parse(user);
        
        // Get users data
        const users = JSON.parse(localStorage.getItem('alitaleh_users') || '{}');
        
        if (users[user.email]) {
            // Initialize orders array if it doesn't exist
            if (!users[user.email].orders) {
                users[user.email].orders = [];
            }
            
            // Add order to user's history
            users[user.email].orders.push(order);
            
            // Update users data
            localStorage.setItem('alitaleh_users', JSON.stringify(users));
            
            // Update current session
            user.orders = users[user.email].orders;
            if (localStorage.getItem('alitaleh_user')) {
                localStorage.setItem('alitaleh_user', JSON.stringify(user));
            } else {
                sessionStorage.setItem('alitaleh_user', JSON.stringify(user));
            }
        }
    }
}

if (bookingForm) {
    bookingForm.addEventListener('submit', (e) => {
        e.preventDefault();
        
        // Get form values
        const formData = {
            name: document.getElementById('name').value,
            email: document.getElementById('email').value,
            phone: document.getElementById('phone').value,
            address: document.getElementById('address').value,
            service: document.getElementById('service').value,
            date: document.getElementById('date').value,
            time: document.getElementById('time').value,
            items: document.getElementById('items').value,
            notes: document.getElementById('notes').value
        };
        
        // Basic validation
        if (!formData.name || !formData.email || !formData.phone || !formData.address) {
            alert('Please fill in all required fields');
            return;
        }
        
        // Email validation
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailRegex.test(formData.email)) {
            alert('Please enter a valid email address');
            return;
        }
        
        // Generate order ID
        const orderId = 'ALI' + Date.now().toString().slice(-5);
        
        // Create order object
        const order = {
            orderId: orderId,
            ...formData,
            status: 'Order Placed',
            total: calculateOrderTotal(formData.service, formData.items),
            createdAt: new Date().toISOString(),
            updatedAt: new Date().toISOString()
        };
        
        // Save order to localStorage
        saveOrderToLocalStorage(orderId, order);
        
        // Add order to user's order history if logged in
        addOrderToUserHistory(order);
        
        // Success message
        alert(`Thank you! Your booking request has been submitted.

Order ID: ${orderId}

We will contact you shortly to confirm your appointment.`);
        
        // Reset form
        bookingForm.reset();
        
        // Show real-time notification
        if (typeof alitalehRT !== 'undefined') {
            alitalehRT.showNotification(`Order #${orderId} has been placed successfully!`, 'info');
        }
        
        // In a real application, you would send this data to a server
        console.log('Booking submitted:', order);
    });
}

// Contact Form
const contactForm = document.getElementById('contactForm');

// Save contact message to localStorage
function saveContactMessage(message) {
    const messages = JSON.parse(localStorage.getItem('alitaleh_contact_messages') || '[]');
    messages.push(message);
    localStorage.setItem('alitaleh_contact_messages', JSON.stringify(messages));
}

if (contactForm) {
    contactForm.addEventListener('submit', (e) => {
        e.preventDefault();
        
        const formData = {
            name: document.getElementById('contactName').value,
            email: document.getElementById('contactEmail').value,
            subject: document.getElementById('subject').value,
            message: document.getElementById('message').value,
            timestamp: new Date().toISOString()
        };
        
        // Basic validation
        if (!formData.name || !formData.email || !formData.message) {
            alert('Please fill in all required fields');
            return;
        }
        
        // Email validation
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailRegex.test(formData.email)) {
            alert('Please enter a valid email address');
            return;
        }
        
        // Save contact message to localStorage
        saveContactMessage(formData);
        
        alert('Thank you for contacting us! We will get back to you soon.');
        contactForm.reset();
        
        // Show real-time notification
        if (typeof alitalehRT !== 'undefined') {
            alitalehRT.showNotification('Your message has been sent successfully! We will respond shortly.', 'info');
        }
        
        console.log('Contact form submitted:', formData);
    });
}

// Smooth scroll for anchor links
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        e.preventDefault();
        const target = document.querySelector(this.getAttribute('href'));
        if (target) {
            target.scrollIntoView({
                behavior: 'smooth',
                block: 'start'
            });
        }
    });
});

// Set active navigation link based on current page
const currentPage = window.location.pathname.split('/').pop() || 'index.html';
document.querySelectorAll('.nav-links a').forEach(link => {
    if (link.getAttribute('href') === currentPage) {
        link.classList.add('active');
    } else {
        link.classList.remove('active');
    }
});

// Add animation on scroll
const observerOptions = {
    threshold: 0.1,
    rootMargin: '0px 0px -100px 0px'
};

const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            entry.target.style.opacity = '1';
            entry.target.style.transform = 'translateY(0)';
        }
    });
}, observerOptions);

// Observe elements for animation
document.querySelectorAll('.feature-card, .step, .testimonial-card, .service-item, .pricing-card').forEach(el => {
    el.style.opacity = '0';
    el.style.transform = 'translateY(20px)';
    el.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
    observer.observe(el);
});

// Set minimum date for booking (today)
const dateInput = document.getElementById('date');
if (dateInput) {
    const today = new Date().toISOString().split('T')[0];
    dateInput.setAttribute('min', today);
}

// Animated Counter for Stats
function animateCounter(element, target, duration = 2000) {
    let current = 0;
    const increment = target / (duration / 16);
    const suffix = element.textContent.replace(/[0-9.,]/g, '');
    
    const timer = setInterval(() => {
        current += increment;
        if (current >= target) {
            element.textContent = formatNumber(target) + suffix;
            clearInterval(timer);
        } else {
            element.textContent = formatNumber(Math.floor(current)) + suffix;
        }
    }, 16);
}

function formatNumber(num) {
    if (num >= 1000) {
        return (num / 1000).toFixed(0) + 'K';
    }
    return num.toString();
}

// Observe stats section for animation
const statsObserver = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
        if (entry.isIntersecting && !entry.target.dataset.animated) {
            const statsCards = entry.target.querySelectorAll('.feature-icon');
            statsCards.forEach(card => {
                const text = card.textContent.trim();
                if (text.includes('+')) {
                    const num = parseInt(text.replace(/[^0-9]/g, ''));
                    if (num) {
                        animateCounter(card, num);
                    }
                }
            });
            entry.target.dataset.animated = 'true';
        }
    });
}, { threshold: 0.5 });

const statsSection = document.querySelector('.features');
if (statsSection) {
    statsObserver.observe(statsSection);
}

// Newsletter Subscription
const newsletterForm = document.getElementById('newsletterForm');
if (newsletterForm) {
    newsletterForm.addEventListener('submit', (e) => {
        e.preventDefault();
        const email = document.getElementById('newsletterEmail').value;
        
        if (email) {
            // Store subscription
            const subscribers = JSON.parse(localStorage.getItem('alitaleh_subscribers') || '[]');
            if (!subscribers.includes(email)) {
                subscribers.push(email);
                localStorage.setItem('alitaleh_subscribers', JSON.stringify(subscribers));
            }
            
            alert('Thank you for subscribing! 🎉\n\nYou\'ll receive our latest offers and updates.');
            newsletterForm.reset();
            
            // Show real-time notification
            if (typeof alitalehRT !== 'undefined') {
                alitalehRT.showNotification('You have been subscribed to our newsletter!', 'info');
            }
        }
    });
}

// Live Chat Toggle
const chatButton = document.getElementById('chatButton');
const chatWidget = document.getElementById('chatWidget');
const closeChat = document.getElementById('closeChat');
const chatForm = document.getElementById('chatForm');
const chatMessages = document.getElementById('chatMessages');
const chatInput = document.getElementById('chatInput');

// Initialize real-time chat
let chatInterval;

function initRealtimeChat() {
    // Set up periodic chat updates
    chatInterval = setInterval(() => {
        simulateAgentResponse();
    }, 45000); // Simulate agent response every 45 seconds
}

function simulateAgentResponse() {
    // Only simulate if chat is open and has messages
    if (chatWidget && chatWidget.style.display !== 'none' && chatMessages && chatMessages.children.length > 0) {
        if (Math.random() > 0.7) {
            const responses = [
                "Thanks for your message! Our team is reviewing your inquiry.",
                "We're experiencing high volume but will respond shortly.",
                "Your request has been escalated to our specialist team.",
                "We appreciate your patience while we look into this for you.",
                "A customer service representative will contact you within 24 hours."
            ];
            
            const randomResponse = responses[Math.floor(Math.random() * responses.length)];
            addChatMessage(randomResponse, 'agent');
            
            // Show notification if real-time system is available
            if (typeof alitalehRT !== 'undefined') {
                alitalehRT.showNotification('New message from customer support', 'info');
            }
        }
    }
}

if (chatButton && chatWidget) {
    chatButton.addEventListener('click', () => {
        chatWidget.style.display = 'flex';
        chatButton.style.display = 'none';
        
        // Initialize real-time chat when widget opens
        initRealtimeChat();
    });
}

if (closeChat) {
    closeChat.addEventListener('click', () => {
        chatWidget.style.display = 'none';
        chatButton.style.display = 'flex';
        
        // Stop real-time chat when widget closes
        if (chatInterval) {
            clearInterval(chatInterval);
            chatInterval = null;
        }
    });
}

if (chatForm) {
    chatForm.addEventListener('submit', (e) => {
        e.preventDefault();
        const message = chatInput.value.trim();
        
        if (message) {
            // Add user message
            addChatMessage(message, 'user');
            chatInput.value = '';
            
            // Send message through real-time system if available
            if (typeof alitalehRT !== 'undefined') {
                alitalehRT.sendMessage(message);
            } else {
                // Simulate bot response
                setTimeout(() => {
                    const response = getChatResponse(message);
                    addChatMessage(response, 'bot');
                }, 1000);
            }
        }
    });
}

function addChatMessage(text, sender) {
    if (!chatMessages) return;
    
    const messageDiv = document.createElement('div');
    messageDiv.className = `chat-message ${sender}`;
    messageDiv.textContent = text;
    chatMessages.appendChild(messageDiv);
    chatMessages.scrollTop = chatMessages.scrollHeight;
    
    // Show notification for new agent messages if widget is closed
    if ((sender === 'agent' || sender === 'bot') && chatWidget.style.display === 'none') {
        if (typeof alitalehRT !== 'undefined') {
            alitalehRT.showNotification('New message from customer support', 'info');
        }
    }
}

function getChatResponse(message) {
    const msg = message.toLowerCase();
    
    if (msg.includes('price') || msg.includes('cost')) {
        return 'Our packages start at $25/week! Visit our Pricing page for details.';
    } else if (msg.includes('hours') || msg.includes('time')) {
        return 'We operate Mon-Fri 7am-8pm, Sat-Sun 9am-6pm. How can we help you?';
    } else if (msg.includes('book') || msg.includes('schedule')) {
        return 'You can book online anytime! Click the "Book Now" button to schedule your pickup.';
    } else if (msg.includes('pickup') || msg.includes('delivery')) {
        return 'We offer free pickup and delivery! Most areas get same-day or next-day service.';
    } else if (msg.includes('payment') || msg.includes('pay')) {
        return 'We accept cash, credit/debit cards, and online payments. Payment is due upon delivery.';
    } else {
        return 'Thanks for your message! A team member will respond shortly. You can also call us at +1 (555) 123-4567.';
    }
}

// Scroll to Top Button
const scrollTopBtn = document.getElementById('scrollTopBtn');

if (scrollTopBtn) {
    window.addEventListener('scroll', () => {
        if (window.pageYOffset > 300) {
            scrollTopBtn.style.display = 'flex';
        } else {
            scrollTopBtn.style.display = 'none';
        }
    });

    scrollTopBtn.addEventListener('click', () => {
        window.scrollTo({
            top: 0,
            behavior: 'smooth'
        });
    });
}

// Service Area Checker
const checkZipBtn = document.getElementById('checkZip');
const zipChecker = document.getElementById('zipChecker');
const zipResult = document.getElementById('zipResult');

if (checkZipBtn && zipChecker && zipResult) {
    checkZipBtn.addEventListener('click', () => {
        const zip = zipChecker.value.trim();
        
        if (!zip) {
            showZipResult('Please enter a ZIP code', 'error');
            return;
        }

        // Simulate service area check (in production, this would call an API)
        const servicedZips = ['12345', '12346', '12347', '54321', '10001', '10002', '90210'];
        
        if (servicedZips.includes(zip)) {
            showZipResult('✅ Great news! We deliver to your area. Free pickup & delivery available!', 'success');
        } else {
            showZipResult('❌ Sorry, we don\'t currently serve this area. We\'re expanding soon! Enter your email below to get notified.', 'error');
        }
    });

    zipChecker.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') {
            checkZipBtn.click();
        }
    });
}

function showZipResult(message, type) {
    if (!zipResult) return;
    
    zipResult.style.display = 'block';
    zipResult.textContent = message;
    
    if (type === 'success') {
        zipResult.style.background = '#d1fae5';
        zipResult.style.color = '#065f46';
        zipResult.style.border = '2px solid #10b981';
        
        // Show real-time notification
        if (typeof alitalehRT !== 'undefined') {
            alitalehRT.showNotification('Great news! We deliver to your area.', 'info');
        }
    } else {
        zipResult.style.background = '#fee2e2';
        zipResult.style.color = '#991b1b';
        zipResult.style.border = '2px solid #ef4444';
        
        // Show real-time notification
        if (typeof alitalehRT !== 'undefined') {
            alitalehRT.showNotification('Sorry, we don\'t currently serve this area.', 'info');
        }
    }
}

// Gallery Filter Functionality
const filterBtns = document.querySelectorAll('.filter-btn');
const galleryItems = document.querySelectorAll('.gallery-item');

filterBtns.forEach(btn => {
    btn.addEventListener('click', () => {
        // Remove active class from all buttons
        filterBtns.forEach(b => b.classList.remove('active'));
        // Add active class to clicked button
        btn.classList.add('active');
        
        const filter = btn.dataset.filter;
        
        galleryItems.forEach(item => {
            if (filter === 'all') {
                item.classList.remove('hide');
                item.style.display = 'block';
            } else {
                if (item.dataset.category === filter) {
                    item.classList.remove('hide');
                    item.style.display = 'block';
                } else {
                    item.classList.add('hide');
                    item.style.display = 'none';
                }
            }
        });
    });
});

// Blog Category Filter
const blogFilterBtns = document.querySelectorAll('[data-category]');
const blogCards = document.querySelectorAll('.blog-card');

if (blogFilterBtns.length > 0 && blogCards.length > 0) {
    blogFilterBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            // Update active button
            blogFilterBtns.forEach(b => b.classList.remove('active'));
            btn.classList.add('active');
            
            const category = btn.dataset.category;
            
            // Filter blog posts
            blogCards.forEach(card => {
                if (category === 'all') {
                    card.style.display = 'flex';
                } else {
                    if (card.dataset.category === category) {
                        card.style.display = 'flex';
                    } else {
                        card.style.display = 'none';
                    }
                }
            });
        });
    });
}

// Blog Newsletter Subscription
const blogNewsletterForm = document.getElementById('blogNewsletterForm');
if (blogNewsletterForm) {
    blogNewsletterForm.addEventListener('submit', (e) => {
        e.preventDefault();
        const email = blogNewsletterForm.querySelector('input[type="email"]').value;
        
        if (email) {
            // Store subscription
            const subscribers = JSON.parse(localStorage.getItem('alitaleh_blog_subscribers') || '[]');
            if (!subscribers.includes(email)) {
                subscribers.push(email);
                localStorage.setItem('alitaleh_blog_subscribers', JSON.stringify(subscribers));
            }
            
            alert('Thank you for subscribing to our blog! 📧\n\nYou\'ll receive our latest posts and tips.');
            blogNewsletterForm.reset();
            
            // Show real-time notification
            if (typeof alitalehRT !== 'undefined') {
                alitalehRT.showNotification('You have been subscribed to our blog!', 'info');
            }
        }
    });
}
