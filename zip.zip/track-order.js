// Track Order Functionality
const trackOrderForm = document.getElementById('trackOrderForm');
const orderStatusDiv = document.getElementById('orderStatus');
const trackAnotherBtn = document.getElementById('trackAnother');

// Initialize real-time order tracking
let realtimeOrderInterval;

function startRealtimeOrderTracking(orderId) {
    // Clear any existing interval
    if (realtimeOrderInterval) {
        clearInterval(realtimeOrderInterval);
    }
    
    // Set up periodic order status checks
    realtimeOrderInterval = setInterval(() => {
        checkOrderStatus(orderId);
    }, 30000); // Check every 30 seconds
}

function stopRealtimeOrderTracking() {
    if (realtimeOrderInterval) {
        clearInterval(realtimeOrderInterval);
        realtimeOrderInterval = null;
    }
}

function checkOrderStatus(orderId) {
    // Get order from localStorage
    const order = getOrderFromLocalStorage(orderId);
    
    if (order) {
        // Simulate order status update
        if (Math.random() > 0.8 && order.status !== 'Delivered' && order.status !== 'Cancelled') {
            const statuses = ['Processing', 'In Transit', 'Out for Delivery', 'Delivered'];
            const currentIndex = statuses.indexOf(order.status);
            
            if (currentIndex < statuses.length - 1) {
                const newStatus = statuses[currentIndex + 1];
                order.status = newStatus;
                order.updatedAt = new Date().toISOString();
                
                // Update order in localStorage
                saveOrderToLocalStorage(orderId, order);
                
                // Update display
                displayOrderStatus(order);
                
                // Show notification
                if (typeof alitalehRT !== 'undefined') {
                    alitalehRT.showNotification(`Order #${orderId} status updated to: ${newStatus}`, 'info');
                }
            }
        }
    }
}

// Sample order data (in production, this would come from a backend API)
const sampleOrders = {
    'ALI12345': {
        orderId: 'ALI12345',
        email: 'john@example.com',
        status: 'Out for Delivery',
        service: 'Popular Package',
        estimatedDelivery: 'Today, 5:00 PM',
        currentStep: 4,
        timeline: {
            step1: '2025-01-15, 10:30 AM',
            step2: '2025-01-15, 2:15 PM',
            step3: '2025-01-16, 9:00 AM',
            step4: '2025-01-17, 3:45 PM',
            step5: ''
        }
    },
    'ALI67890': {
        orderId: 'ALI67890',
        email: 'sarah@example.com',
        status: 'Delivered',
        service: 'Premium Package',
        estimatedDelivery: 'Delivered on Jan 16',
        currentStep: 5,
        timeline: {
            step1: '2025-01-14, 9:00 AM',
            step2: '2025-01-14, 1:30 PM',
            step3: '2025-01-15, 8:00 AM',
            step4: '2025-01-16, 10:00 AM',
            step5: '2025-01-16, 4:30 PM'
        }
    },
    'ALI54321': {
        orderId: 'ALI54321',
        email: 'mike@example.com',
        status: 'In Processing',
        service: 'Basic Package',
        estimatedDelivery: 'Tomorrow, 6:00 PM',
        currentStep: 3,
        timeline: {
            step1: '2025-01-16, 11:00 AM',
            step2: '2025-01-16, 3:00 PM',
            step3: '2025-01-17, 8:30 AM',
            step4: '',
            step5: ''
        }
    }
};

if (trackOrderForm) {
    trackOrderForm.addEventListener('submit', (e) => {
        e.preventDefault();
        
        const orderId = document.getElementById('orderId').value.trim().toUpperCase();
        const email = document.getElementById('trackEmail').value.trim().toLowerCase();
        
        // Check if order exists
        const order = sampleOrders[orderId];
        
        if (!order) {
            alert('Order not found. Please check your Order ID and try again.');
            return;
        }
        
        if (order.email.toLowerCase() !== email) {
            alert('Email address does not match our records. Please verify and try again.');
            return;
        }
        
        // Display order status
        displayOrderStatus(order);
    });
}

function displayOrderStatus(order) {
    // Hide form, show status
    trackOrderForm.parentElement.style.display = 'none';
    orderStatusDiv.style.display = 'block';
    
    // Start real-time tracking
    startRealtimeOrderTracking(order.orderId);
    
    // Populate order info
    document.getElementById('displayOrderId').textContent = order.orderId;
    document.getElementById('displayStatus').textContent = order.status;
    document.getElementById('displayService').textContent = order.service;
    document.getElementById('displayDelivery').textContent = order.estimatedDelivery;
    
    // Set status color
    const statusElement = document.getElementById('displayStatus');
    if (order.status === 'Delivered') {
        statusElement.style.color = 'var(--success-color)';
    } else if (order.status === 'Out for Delivery') {
        statusElement.style.color = 'var(--primary-color)';
    } else {
        statusElement.style.color = '#f59e0b';
    }
    
    // Update timeline
    updateTimeline(order);
    
    // Scroll to status
    orderStatusDiv.scrollIntoView({ behavior: 'smooth', block: 'start' });
}

function updateTimeline(order) {
    // Reset all steps
    for (let i = 1; i <= 5; i++) {
        const step = document.getElementById(`step${i}`);
        const timeElement = document.getElementById(`step${i}Time`);
        
        if (i <= order.currentStep) {
            step.classList.add('completed');
            timeElement.textContent = order.timeline[`step${i}`] || 'Completed';
        } else {
            step.classList.remove('completed');
            timeElement.textContent = 'Pending';
        }
    }
}

if (trackAnotherBtn) {
    trackAnotherBtn.addEventListener('click', () => {
        // Stop real-time tracking
        stopRealtimeOrderTracking();
        
        trackOrderForm.parentElement.style.display = 'block';
        orderStatusDiv.style.display = 'none';
        trackOrderForm.reset();
        window.scrollTo({ top: 0, behavior: 'smooth' });
    });
}

// Function to fill sample order (called from HTML onclick)
function fillSampleOrder(orderId, email) {
    document.getElementById('orderId').value = orderId;
    document.getElementById('trackEmail').value = email;
    
    // Scroll to form
    trackOrderForm.scrollIntoView({ behavior: 'smooth', block: 'center' });
    
    // Highlight the form
    trackOrderForm.parentElement.style.boxShadow = '0 0 0 3px var(--primary-color)';
    setTimeout(() => {
        trackOrderForm.parentElement.style.boxShadow = 'var(--shadow-lg)';
    }, 1000);
}

// Make function globally available
window.fillSampleOrder = fillSampleOrder;

// Store order in localStorage after booking
function saveOrderToLocalStorage(orderId, orderData) {
    const orders = JSON.parse(localStorage.getItem('alitaleh_orders') || '{}');
    orders[orderId] = orderData;
    localStorage.setItem('alitaleh_orders', JSON.stringify(orders));
}

// Retrieve order from localStorage
function getOrderFromLocalStorage(orderId) {
    const orders = JSON.parse(localStorage.getItem('alitaleh_orders') || '{}');
    return orders[orderId] || null;
}
