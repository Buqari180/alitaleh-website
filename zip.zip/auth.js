// Authentication functionality
const AUTH_STORAGE_KEY = 'alitaleh_user';
const USERS_STORAGE_KEY = 'alitaleh_users';

// Initialize real-time functionality on login
function initRealtimeOnLogin() {
    if (typeof alitalehRT !== 'undefined') {
        // Update user info in real-time system
        alitalehRT.user = getCurrentUser();
        alitalehRT.sendUserInfo();
        
        // Show welcome notification
        alitalehRT.showNotification('Welcome back! You are now connected in real-time.', 'info');
    }
}

// Tab switching
function switchTab(tab) {
    const tabs = document.querySelectorAll('.auth-tab');
    const forms = document.querySelectorAll('.auth-form');
    
    tabs.forEach(t => {
        if (t.dataset.tab === tab) {
            t.classList.add('active');
        } else {
            t.classList.remove('active');
        }
    });
    
    forms.forEach(f => {
        if (f.id === `${tab}Tab`) {
            f.classList.add('active');
        } else {
            f.classList.remove('active');
        }
    });
}

// Tab click handlers
document.querySelectorAll('.auth-tab').forEach(tab => {
    tab.addEventListener('click', () => {
        switchTab(tab.dataset.tab);
    });
});

// Login Form
const loginForm = document.getElementById('loginForm');
if (loginForm) {
    loginForm.addEventListener('submit', (e) => {
        e.preventDefault();
        
        const email = document.getElementById('loginEmail').value.trim().toLowerCase();
        const password = document.getElementById('loginPassword').value;
        const rememberMe = document.getElementById('rememberMe').checked;
        
        // Get users from storage
        const users = JSON.parse(localStorage.getItem(USERS_STORAGE_KEY) || '{}');
        
        // Check if user exists and password matches
        if (users[email] && users[email].password === password) {
            // Store current user
            const userData = {
                ...users[email],
                loggedIn: true,
                loginTime: new Date().toISOString()
            };
            
            delete userData.password; // Don't store password in session
            
            if (rememberMe) {
                localStorage.setItem(AUTH_STORAGE_KEY, JSON.stringify(userData));
            } else {
                sessionStorage.setItem(AUTH_STORAGE_KEY, JSON.stringify(userData));
            }
            
            alert(`Welcome back, ${userData.name}! 🎉`);
            
            // Initialize real-time functionality
            initRealtimeOnLogin();
            
            // Redirect to profile
            window.location.href = 'profile.html';
        } else {
            alert('Invalid email or password. Please try again.');
        }
    });
}

// Register Form
const registerForm = document.getElementById('registerForm');
if (registerForm) {
    registerForm.addEventListener('submit', (e) => {
        e.preventDefault();
        
        const name = document.getElementById('registerName').value.trim();
        const email = document.getElementById('registerEmail').value.trim().toLowerCase();
        const phone = document.getElementById('registerPhone').value.trim();
        const password = document.getElementById('registerPassword').value;
        const confirmPassword = document.getElementById('confirmPassword').value;
        const address = document.getElementById('registerAddress').value.trim();
        
        // Validation
        if (password.length < 8) {
            alert('Password must be at least 8 characters long');
            return;
        }
        
        if (password !== confirmPassword) {
            alert('Passwords do not match');
            return;
        }
        
        // Get existing users
        const users = JSON.parse(localStorage.getItem(USERS_STORAGE_KEY) || '{}');
        
        // Check if user already exists
        if (users[email]) {
            alert('An account with this email already exists. Please login.');
            switchTab('login');
            return;
        }
        
        // Create new user
        const newUser = {
            name: name,
            email: email,
            phone: phone,
            password: password,
            address: address,
            createdAt: new Date().toISOString(),
            orders: [],
            addresses: [
                {
                    id: Date.now(),
                    type: 'Home',
                    address: address,
                    isDefault: true
                }
            ],
            paymentMethods: [],
            preferences: {
                emailNotifications: true,
                smsNotifications: true,
                marketingCommunications: false,
                defaultStarch: 'medium'
            }
        };
        
        // Save user
        users[email] = newUser;
        localStorage.setItem(USERS_STORAGE_KEY, JSON.stringify(users));
        
        // Auto login
        const userData = { ...newUser };
        delete userData.password;
        userData.loggedIn = true;
        userData.loginTime = new Date().toISOString();
        
        localStorage.setItem(AUTH_STORAGE_KEY, JSON.stringify(userData));
        
        alert(`Account created successfully! Welcome, ${name}! 🎉`);
        
        // Initialize real-time functionality
        initRealtimeOnLogin();
        
        // Redirect to profile
        window.location.href = 'profile.html';
    });
}

// Check if user is logged in
function getCurrentUser() {
    let user = localStorage.getItem(AUTH_STORAGE_KEY);
    if (!user) {
        user = sessionStorage.getItem(AUTH_STORAGE_KEY);
    }
    return user ? JSON.parse(user) : null;
}

// Protect profile page
if (window.location.pathname.includes('profile.html')) {
    const user = getCurrentUser();
    if (!user || !user.loggedIn) {
        alert('Please login to access your profile');
        window.location.href = 'login.html';
    }
}

// Logout function
function logout() {
    localStorage.removeItem(AUTH_STORAGE_KEY);
    sessionStorage.removeItem(AUTH_STORAGE_KEY);
    alert('You have been logged out successfully');
    window.location.href = 'index.html';
}

// Global logout handler
const logoutBtn = document.getElementById('logoutBtn');
if (logoutBtn) {
    logoutBtn.addEventListener('click', (e) => {
        e.preventDefault();
        logout();
    });
}

// User menu toggle
const userMenuBtn = document.getElementById('userMenuBtn');
const userDropdown = document.getElementById('userDropdown');

if (userMenuBtn && userDropdown) {
    userMenuBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        userDropdown.classList.toggle('show');
    });
    
    // Close dropdown when clicking outside
    document.addEventListener('click', () => {
        userDropdown.classList.remove('show');
    });
}

// Update navigation based on login state
function updateNavigation() {
    const user = getCurrentUser();
    const loginBtn = document.querySelector('.navbar .btn.primary');
    
    if (user && user.loggedIn) {
        // User is logged in
        if (loginBtn && loginBtn.textContent === 'Login') {
            loginBtn.outerHTML = `
                <div class="user-menu">
                    <button class="user-menu-btn" id="userMenuBtn">
                        <span>${user.name.split(' ')[0]}</span> 👤
                    </button>
                    <div class="user-dropdown" id="userDropdown">
                        <a href="profile.html">My Profile</a>
                        <a href="#" onclick="logout()">Logout</a>
                    </div>
                </div>
            `;
        }
    }
}

// Call on page load
if (!window.location.pathname.includes('login.html') && !window.location.pathname.includes('profile.html')) {
    updateNavigation();
}
