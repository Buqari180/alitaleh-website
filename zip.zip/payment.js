// Payment page functionality
document.addEventListener('DOMContentLoaded', () => {
    // Get package data from URL parameters
    const urlParams = new URLSearchParams(window.location.search);
    const packageType = urlParams.get('package') || 'popular';
    
    // Package data
    const packages = {
        basic: {
            name: 'Basic Package',
            price: 25,
            frequency: 'Weekly',
            features: [
                'Up to 10 items per week',
                'Standard ironing',
                'Free pickup & delivery',
                '48-hour turnaround',
                'Email support'
            ]
        },
        popular: {
            name: 'Popular Package',
            price: 45,
            frequency: 'Weekly',
            features: [
                'Up to 20 items per week',
                'Professional ironing',
                'Free pickup & delivery',
                '24-hour turnaround',
                'Priority support',
                'Starch options included',
                '10% discount on extras'
            ]
        },
        premium: {
            name: 'Premium Package',
            price: 75,
            frequency: 'Weekly',
            features: [
                'Unlimited items',
                'Expert delicate care',
                'Free pickup & delivery',
                'Same-day service available',
                '24/7 phone support',
                'All extras included',
                'Dedicated account manager',
                'Quality guarantee'
            ]
        }
    };

    // Load package details
    const selectedPackage = packages[packageType];
    
    if (selectedPackage) {
        // Calculate prices
        const basePrice = selectedPackage.price;
        const discount = basePrice * 0.20; // 20% first-time discount
        const totalPrice = basePrice - discount;

        // Update UI
        document.getElementById('packageName').textContent = selectedPackage.name;
        document.getElementById('packagePrice').textContent = `$${basePrice.toFixed(2)}`;
        document.getElementById('frequency').textContent = selectedPackage.frequency;
        document.getElementById('discount').textContent = `-$${discount.toFixed(2)}`;
        document.getElementById('totalPrice').textContent = `$${totalPrice.toFixed(2)}`;

        // Display features
        const featuresHTML = selectedPackage.features
            .map(feature => `<p style="margin: 0.5rem 0;">✓ ${feature}</p>`)
            .join('');
        document.getElementById('packageFeatures').innerHTML = featuresHTML;

        // Store data for form submission
        window.selectedPackageData = {
            package: selectedPackage.name,
            basePrice: basePrice,
            discount: discount,
            total: totalPrice
        };
    } else {
        // Redirect to pricing if no valid package
        window.location.href = 'pricing.html';
    }
});

// Card number formatting
document.getElementById('cardNumber')?.addEventListener('input', (e) => {
    let value = e.target.value.replace(/\s/g, '');
    let formattedValue = value.match(/.{1,4}/g)?.join(' ') || value;
    e.target.value = formattedValue;
});

// Expiry date formatting
document.getElementById('expiry')?.addEventListener('input', (e) => {
    let value = e.target.value.replace(/\D/g, '');
    if (value.length >= 2) {
        value = value.slice(0, 2) + '/' + value.slice(2, 4);
    }
    e.target.value = value;
});

// CVV - numbers only
document.getElementById('cvv')?.addEventListener('input', (e) => {
    e.target.value = e.target.value.replace(/\D/g, '');
});

// ZIP code formatting
document.getElementById('zipCode')?.addEventListener('input', (e) => {
    e.target.value = e.target.value.replace(/[^\d-]/g, '');
});

// Payment form submission
document.getElementById('paymentForm')?.addEventListener('submit', (e) => {
    e.preventDefault();

    // Get form data
    const formData = {
        cardName: document.getElementById('cardName').value,
        cardNumber: document.getElementById('cardNumber').value,
        expiry: document.getElementById('expiry').value,
        cvv: document.getElementById('cvv').value,
        billingEmail: document.getElementById('billingEmail').value,
        billingAddress: document.getElementById('billingAddress').value,
        city: document.getElementById('city').value,
        zipCode: document.getElementById('zipCode').value,
        terms: document.getElementById('terms').checked
    };

    // Validate card number (basic check)
    const cardDigits = formData.cardNumber.replace(/\s/g, '');
    if (cardDigits.length < 15 || cardDigits.length > 16) {
        alert('Please enter a valid card number');
        return;
    }

    // Validate expiry
    const expiryParts = formData.expiry.split('/');
    if (expiryParts.length !== 2) {
        alert('Please enter a valid expiry date (MM/YY)');
        return;
    }
    const expMonth = parseInt(expiryParts[0]);
    const expYear = parseInt('20' + expiryParts[1]);
    const currentDate = new Date();
    const currentYear = currentDate.getFullYear();
    const currentMonth = currentDate.getMonth() + 1;

    if (expMonth < 1 || expMonth > 12) {
        alert('Please enter a valid month (01-12)');
        return;
    }

    if (expYear < currentYear || (expYear === currentYear && expMonth < currentMonth)) {
        alert('Card has expired. Please use a valid card');
        return;
    }

    // Validate CVV
    if (formData.cvv.length < 3 || formData.cvv.length > 4) {
        alert('Please enter a valid CVV');
        return;
    }

    // Validate terms
    if (!formData.terms) {
        alert('Please accept the Terms & Conditions');
        return;
    }

    // Store payment data (in production, this would be sent to a payment processor)
    const paymentData = {
        ...window.selectedPackageData,
        billingEmail: formData.billingEmail,
        billingAddress: formData.billingAddress,
        city: formData.city,
        zipCode: formData.zipCode,
        timestamp: new Date().toISOString(),
        status: 'completed'
    };

    // Store in localStorage
    localStorage.setItem('alitaleh_payment', JSON.stringify(paymentData));

    // Show success message
    alert(`Payment Successful! 🎉

Thank you for choosing ${paymentData.package}!

Total Paid: $${paymentData.total.toFixed(2)}

A confirmation email has been sent to ${formData.billingEmail}.

You will be redirected to book your first pickup.`);

    // Redirect to booking page
    setTimeout(() => {
        window.location.href = 'booking.html';
    }, 1000);
});

// Add responsive layout for mobile
if (window.innerWidth <= 768) {
    const paymentGrid = document.querySelector('.booking-form .container > div');
    if (paymentGrid) {
        paymentGrid.style.gridTemplateColumns = '1fr';
    }
}

window.addEventListener('resize', () => {
    const paymentGrid = document.querySelector('.booking-form .container > div');
    if (paymentGrid) {
        if (window.innerWidth <= 768) {
            paymentGrid.style.gridTemplateColumns = '1fr';
        } else {
            paymentGrid.style.gridTemplateColumns = '1fr 1fr';
        }
    }
});
