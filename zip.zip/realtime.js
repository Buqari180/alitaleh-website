// Real-time functionality for Alitaleh website
class AlitalehRealtime {
    constructor() {
        this.socket = null;
        this.isConnected = false;
        this.user = null;
        this.reconnectAttempts = 0;
        this.maxReconnectAttempts = 5;
        this.reconnectDelay = 1000; // 1 second
        this.initialize();
    }

    initialize() {
        // Get current user
        this.user = this.getCurrentUser();
        
        // Initialize WebSocket connection
        this.initWebSocket();
        
        // Set up real-time features
        this.setupRealTimeFeatures();
        
        // Set up periodic updates
        this.setupPeriodicUpdates();
    }

    getCurrentUser() {
        let user = localStorage.getItem('alitaleh_user');
        if (!user) {
            user = sessionStorage.getItem('alitaleh_user');
        }
        return user ? JSON.parse(user) : null;
    }

    initWebSocket() {
        try {
            // In a real implementation, you would connect to your WebSocket server
            // For demonstration, we'll use a mock WebSocket URL
            const wsUrl = 'ws://localhost:8080'; // Replace with your actual WebSocket server
            
            // Create WebSocket connection
            this.socket = new WebSocket(wsUrl);
            
            // Set up WebSocket event handlers
            this.setupWebSocketEvents();
            
            console.log('Attempting WebSocket connection to:', wsUrl);
        } catch (error) {
            console.error('WebSocket initialization error:', error);
            // Fallback to simulated real-time behavior
            this.initSimulatedRealTime();
        }
    }

    setupWebSocketEvents() {
        if (!this.socket) return;

        // Connection opened
        this.socket.addEventListener('open', (event) => {
            console.log('WebSocket connection established');
            this.isConnected = true;
            this.reconnectAttempts = 0;
            this.onConnect();
            
            // Send user info if logged in
            if (this.user) {
                this.sendUserInfo();
            }
        });

        // Listen for messages
        this.socket.addEventListener('message', (event) => {
            try {
                const data = JSON.parse(event.data);
                this.handleWebSocketMessage(data);
            } catch (error) {
                console.error('Error parsing WebSocket message:', error);
            }
        });

        // Connection closed
        this.socket.addEventListener('close', (event) => {
            console.log('WebSocket connection closed:', event.code, event.reason);
            this.isConnected = false;
            
            // Attempt to reconnect if not closed intentionally
            if (!event.wasClean && this.reconnectAttempts < this.maxReconnectAttempts) {
                this.reconnectWebSocket();
            }
        });

        // Connection error
        this.socket.addEventListener('error', (error) => {
            console.error('WebSocket error:', error);
            this.isConnected = false;
        });
    }

    handleWebSocketMessage(data) {
        console.log('Received WebSocket message:', data);
        
        switch (data.type) {
            case 'orderUpdate':
                this.handleOrderUpdate(data.payload);
                break;
            case 'notification':
                this.showNotification(data.payload.message, data.payload.type || 'info');
                break;
            case 'chatMessage':
                this.handleChatMessage(data.payload);
                break;
            case 'userUpdate':
                this.handleUserUpdate(data.payload);
                break;
            default:
                console.log('Unknown message type:', data.type);
        }
    }

    handleOrderUpdate(orderData) {
        // Update order display if on track order page
        if (window.location.pathname.includes('track-order.html')) {
            this.updateTrackOrderDisplay(orderData);
        }
        
        // Update order in profile if on profile page
        if (window.location.pathname.includes('profile.html')) {
            this.updateProfileOrderDisplay(orderData);
        }
        
        // Show notification
        this.showNotification(`Order #${orderData.orderId} status updated to: ${orderData.status}`, 'info');
        
        // Dispatch custom event for other parts of the application
        const event = new CustomEvent('orderUpdate', {
            detail: { order: orderData }
        });
        document.dispatchEvent(event);
    }

    handleChatMessage(messageData) {
        // Add message to chat
        this.addChatMessage(messageData.text, messageData.sender);
        
        // Show notification if chat is not open
        const chatWidget = document.getElementById('chatWidget');
        if (chatWidget && chatWidget.style.display === 'none') {
            this.showNotification('New message from customer support', 'info');
        }
    }

    handleUserUpdate(userData) {
        // Update user data
        this.user = userData;
        
        // Update session storage
        if (localStorage.getItem('alitaleh_user')) {
            localStorage.setItem('alitaleh_user', JSON.stringify(userData));
        } else {
            sessionStorage.setItem('alitaleh_user', JSON.stringify(userData));
        }
        
        // Dispatch user update event
        const event = new CustomEvent('userUpdate', {
            detail: { user: userData }
        });
        document.dispatchEvent(event);
    }

    reconnectWebSocket() {
        console.log(`Attempting to reconnect (${this.reconnectAttempts + 1}/${this.maxReconnectAttempts})`);
        
        this.reconnectAttempts++;
        
        setTimeout(() => {
            this.initWebSocket();
        }, this.reconnectDelay * this.reconnectAttempts); // Exponential backoff
    }

    initSimulatedRealTime() {
        console.log('Initializing simulated real-time connection...');
        
        // Simulate connection
        setTimeout(() => {
            this.isConnected = true;
            this.onConnect();
        }, 1000);
    }

    // Public methods for sending data through WebSocket
    send(data) {
        if (this.isConnected && this.socket && this.socket.readyState === WebSocket.OPEN) {
            this.socket.send(JSON.stringify(data));
        } else {
            console.warn('WebSocket not connected. Message not sent:', data);
        }
    }

    sendOrderUpdate(orderId, status) {
        this.send({
            type: 'orderUpdate',
            payload: { orderId, status }
        });
    }

    sendMessage(message) {
        this.send({
            type: 'chatMessage',
            payload: { 
                text: message, 
                sender: 'user',
                timestamp: new Date().toISOString()
            }
        });
    }

    sendUserInfo() {
        if (this.user) {
            this.send({
                type: 'userInfo',
                payload: this.user
            });
        }
    }

    onConnect() {
        console.log('Real-time connection established');
        
        // Send user info if logged in
        if (this.user) {
            this.sendUserInfo();
        }
        
        // Start simulated real-time updates
        this.startSimulatedUpdates();
    }

    sendUserInfo() {
        // In a real implementation, this would send user data to the server
        console.log('Sending user info:', this.user);
    }

    startSimulatedUpdates() {
        // Simulate real-time order status updates
        setInterval(() => {
            if (this.user) {
                this.simulateOrderUpdates();
            }
        }, 30000); // Every 30 seconds

        // Simulate real-time notifications
        setInterval(() => {
            this.simulateNotifications();
        }, 60000); // Every minute
    }

    simulateOrderUpdates() {
        // Get user orders from localStorage
        const users = JSON.parse(localStorage.getItem('alitaleh_users') || '{}');
        const userData = users[this.user.email];
        
        if (userData && userData.orders && userData.orders.length > 0) {
            // Randomly update order status for demonstration
            const orders = userData.orders;
            const randomOrderIndex = Math.floor(Math.random() * orders.length);
            const order = orders[randomOrderIndex];
            
            // Only update if order is not already delivered
            if (order.status !== 'Delivered' && order.status !== 'Cancelled') {
                const statuses = ['Processing', 'In Transit', 'Out for Delivery', 'Delivered'];
                const currentIndex = statuses.indexOf(order.status);
                
                if (currentIndex < statuses.length - 1) {
                    const newStatus = statuses[currentIndex + 1];
                    order.status = newStatus;
                    order.updatedAt = new Date().toISOString();
                    
                    // Update user data
                    users[this.user.email] = userData;
                    localStorage.setItem('alitaleh_users', JSON.stringify(users));
                    
                    // Show notification
                    this.showNotification(`Order #${order.orderId} status updated to: ${newStatus}`, 'info');
                    
                    // Trigger order update event
                    this.triggerOrderUpdate(order);
                }
            }
        }
    }

    simulateNotifications() {
        // Random notifications for demonstration
        const notifications = [
            'Special offer: 25% off all services this week!',
            'New eco-friendly cleaning options now available',
            'Your scheduled pickup is confirmed for tomorrow',
            'Thank you for your recent order! How was your experience?',
            'Refer a friend and get $10 credit'
        ];
        
        const randomNotification = notifications[Math.floor(Math.random() * notifications.length)];
        this.showNotification(randomNotification, 'info');
    }

    showNotification(message, type = 'info') {
        // Create notification element
        const notification = document.createElement('div');
        notification.className = `realtime-notification ${type}`;
        notification.innerHTML = `
            <div class="notification-content">
                <span class="notification-icon">${type === 'info' ? 'ℹ️' : '⚠️'}</span>
                <span class="notification-message">${message}</span>
                <button class="notification-close">×</button>
            </div>
        `;
        
        // Add to document
        document.body.appendChild(notification);
        
        // Add close functionality
        const closeBtn = notification.querySelector('.notification-close');
        closeBtn.addEventListener('click', () => {
            notification.remove();
        });
        
        // Auto-remove after 5 seconds
        setTimeout(() => {
            if (notification.parentNode) {
                notification.remove();
            }
        }, 5000);
    }

    triggerOrderUpdate(order) {
        // Dispatch custom event for order updates
        const event = new CustomEvent('orderUpdate', {
            detail: { order: order }
        });
        document.dispatchEvent(event);
    }

    setupRealTimeFeatures() {
        // Set up order tracking updates
        this.setupOrderTracking();
        
        // Set up live chat enhancements
        this.setupLiveChat();
        
        // Set up real-time user status
        this.setupUserStatus();
    }

    setupOrderTracking() {
        // Listen for order updates
        document.addEventListener('orderUpdate', (e) => {
            const order = e.detail.order;
            
            // Update order display if on track order page
            if (window.location.pathname.includes('track-order.html')) {
                this.updateTrackOrderDisplay(order);
            }
            
            // Update order in profile if on profile page
            if (window.location.pathname.includes('profile.html')) {
                this.updateProfileOrderDisplay(order);
            }
        });
    }

    updateTrackOrderDisplay(order) {
        // Update the tracking display with new status
        const statusElement = document.getElementById('displayStatus');
        const deliveryElement = document.getElementById('displayDelivery');
        
        if (statusElement) {
            statusElement.textContent = order.status;
            
            // Update status color
            if (order.status === 'Delivered') {
                statusElement.style.color = 'var(--success-color)';
            } else if (order.status === 'Out for Delivery') {
                statusElement.style.color = 'var(--primary-color)';
            } else {
                statusElement.style.color = '#f59e0b';
            }
        }
        
        if (deliveryElement) {
            deliveryElement.textContent = order.status === 'Delivered' 
                ? `Delivered on ${new Date(order.updatedAt).toLocaleDateString()}` 
                : 'Estimated delivery: Soon';
        }
    }

    updateProfileOrderDisplay(order) {
        // Update order status in profile
        const orderElement = document.querySelector(`.order-card[data-order-id="${order.orderId}"]`);
        if (orderElement) {
            const statusElement = orderElement.querySelector('.order-status');
            if (statusElement) {
                statusElement.textContent = order.status;
                statusElement.className = `order-status status-${order.status.toLowerCase().replace(' ', '-')}`;
            }
        }
    }

    setupLiveChat() {
        // Enhance live chat with real-time features
        const chatMessages = document.getElementById('chatMessages');
        if (chatMessages) {
            // Simulate real-time agent responses
            setInterval(() => {
                if (Math.random() > 0.7 && chatMessages.children.length > 0) {
                    this.simulateAgentResponse();
                }
            }, 45000); // Every 45 seconds
        }
    }

    simulateAgentResponse() {
        const responses = [
            "Thanks for your message! Our team is reviewing your inquiry.",
            "We're experiencing high volume but will respond shortly.",
            "Your request has been escalated to our specialist team.",
            "We appreciate your patience while we look into this for you.",
            "A customer service representative will contact you within 24 hours."
        ];
        
        const randomResponse = responses[Math.floor(Math.random() * responses.length)];
        this.addChatMessage(randomResponse, 'agent');
    }

    addChatMessage(text, sender) {
        const chatMessages = document.getElementById('chatMessages');
        if (chatMessages) {
            const messageDiv = document.createElement('div');
            messageDiv.className = `chat-message ${sender}`;
            messageDiv.textContent = text;
            chatMessages.appendChild(messageDiv);
            chatMessages.scrollTop = chatMessages.scrollHeight;
        }
    }

    setupUserStatus() {
        // Update user status in real-time
        if (this.user) {
            // Update last seen status
            setInterval(() => {
                this.updateUserLastSeen();
            }, 60000); // Every minute
        }
    }

    updateUserLastSeen() {
        if (this.user) {
            this.user.lastSeen = new Date().toISOString();
            
            // Update in storage
            if (localStorage.getItem('alitaleh_user')) {
                localStorage.setItem('alitaleh_user', JSON.stringify(this.user));
            } else {
                sessionStorage.setItem('alitaleh_user', JSON.stringify(this.user));
            }
        }
    }

    setupPeriodicUpdates() {
        // Periodically check for updates
        setInterval(() => {
            this.checkForUpdates();
        }, 30000); // Every 30 seconds
    }

    checkForUpdates() {
        // Check for new messages, notifications, etc.
        if (this.user) {
            this.checkForNewMessages();
            this.checkForSystemUpdates();
        }
    }

    checkForNewMessages() {
        // Simulate checking for new messages
        if (Math.random() > 0.8) {
            this.showNotification('You have a new message from customer support', 'info');
        }
    }

    checkForSystemUpdates() {
        // Simulate system updates
        if (Math.random() > 0.95) {
            this.showNotification('System maintenance scheduled for tonight', 'info');
        }
    }

    // Public methods for other parts of the application to use
    sendOrderUpdate(orderId, status) {
        // In a real implementation, this would send to the server
        console.log(`Sending order update: ${orderId} -> ${status}`);
        
        // For simulation, just trigger the update
        const event = new CustomEvent('orderUpdate', {
            detail: { 
                order: { 
                    orderId: orderId, 
                    status: status, 
                    updatedAt: new Date().toISOString() 
                } 
            }
        });
        document.dispatchEvent(event);
    }

    sendMessage(message) {
        // In a real implementation, this would send to the server
        console.log('Sending message:', message);
        
        // For simulation, just show it in chat
        this.addChatMessage(message, 'user');
        
        // Simulate response after a delay
        setTimeout(() => {
            this.simulateAgentResponse();
        }, 2000);
    }
}

// Initialize real-time functionality when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    // Create global instance
    window.alitalehRT = new AlitalehRealtime();
    
    // Add real-time notification container to body
    const notificationContainer = document.createElement('div');
    notificationContainer.id = 'realtime-notifications';
    notificationContainer.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        z-index: 10000;
        width: 300px;
    `;
    document.body.appendChild(notificationContainer);
    
    // Add CSS for notifications
    const style = document.createElement('style');
    style.textContent = `
        .realtime-notification {
            background: white;
            border-radius: 8px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.15);
            margin-bottom: 10px;
            overflow: hidden;
            animation: slideIn 0.3s ease-out;
        }
        
        @keyframes slideIn {
            from { transform: translateX(100%); opacity: 0; }
            to { transform: translateX(0); opacity: 1; }
        }
        
        .notification-content {
            display: flex;
            align-items: center;
            padding: 15px;
            gap: 10px;
        }
        
        .notification-icon {
            font-size: 1.2em;
        }
        
        .notification-message {
            flex: 1;
            font-size: 0.9em;
            color: #333;
        }
        
        .notification-close {
            background: none;
            border: none;
            font-size: 1.5em;
            cursor: pointer;
            color: #999;
            padding: 0;
            width: 20px;
            height: 20px;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        
        .notification-close:hover {
            color: #333;
        }
    `;
    document.head.appendChild(style);
});

// Make the class available globally
window.AlitalehRealtime = AlitalehRealtime;